// Функция симуляции клика мышью
function clickElement(el) {
  if (!el) return;
  const opts = { bubbles: true, cancelable: true, view: window };
  
  // Устанавливаем глобальный атрибут на элемент, чтобы знать, что клик отправлен скриптом
  el.dataset.scriptClick = 'true';

  ['mousedown', 'mouseup', 'click'].forEach((evt) => {
    el.dispatchEvent(new MouseEvent(evt, opts));
  });

  // Снимаем атрибут через небольшую паузу
  setTimeout(() => {
    delete el.dataset.scriptClick;
  }, 100);
}

// Поиск и клик по пункту "Скрыть" в меню YouTube
function triggerHideOption() {
  return new Promise((resolve) => {
    const start = Date.now();
    const interval = setInterval(() => {
      // Расширенный поиск по элементам выпадающего меню
      const items = Array.from(
        document.querySelectorAll(
          'yt-list-item-view-model, ' +
          'ytd-menu-service-item-renderer, ' +
          'tp-yt-paper-item, ' +
          'ytd-compact-link-renderer, ' +
          'ytd-menu-navigation-item-renderer'
        )
      );

      const hideItem = items.find((item) => {
        const text = (item.innerText || '').toLowerCase();
        return text.includes('скрыть') || text.includes('hide') || text.includes('не интересно');
      });

      if (hideItem) {
        clearInterval(interval);
        const clickable = hideItem.querySelector('button, a, tp-yt-paper-item') || hideItem;
        clickElement(clickable);
        resolve(true);
      } else if (Date.now() - start > 1000) {
        clearInterval(interval);
        resolve(false);
      }
    }, 40);
  });
}

async function handleMenuClick(e, btn, card) {
  // 1. Если клик вызван программно нашим скриптом — разрешаем обработку YouTube и выходим
  if (btn.dataset.scriptClick === 'true') {
    return;
  }

  // 2. Блокируем стандартный клик пользователя по кнопке трех точек
  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();

  // Защита от повторных нажатий во время обработки
  if (btn.dataset.isProcessing === 'true') return;
  btn.dataset.isProcessing = 'true';

  card.style.opacity = '0.3';
  card.style.pointerEvents = 'none';

  // Прячем меню временно, чтобы оно не моргало на экране
  document.body.classList.add('yt-hide-popup-active');

  // Запускаем открытие меню
  clickElement(btn);

  // Ожидаем появления и нажимаем "Скрыть"
  const success = await triggerHideOption();

  document.body.classList.remove('yt-hide-popup-active');
  btn.dataset.isProcessing = 'false';

  if (success) {
    console.log('[YT Direct Hide] Видео успешно скрыто!');
    setTimeout(() => {
      card.style.display = 'none';
    }, 150);
  } else {
    console.warn('[YT Direct Hide] Не удалось найти пункт "Скрыть".');
    card.style.opacity = '1';
    card.style.pointerEvents = 'auto';
  }
}

function processMenuButtons() {
  const cards = document.querySelectorAll(
    'ytd-rich-item-renderer, ' +
    'ytd-grid-video-renderer, ' +
    'ytd-rich-grid-media, ' +
    'yt-lockup-view-model, ' +
    'ytd-video-renderer'
  );

  cards.forEach((card) => {
    const menuBtn = card.querySelector(
      '.ytLockupMetadataViewModelMenuButton button, ' +
      'ytd-menu-renderer button, ' +
      'button[aria-label="Ещё"], ' +
      'button[aria-label="Action menu"]'
    );

    if (!menuBtn || menuBtn.dataset.quickHideAttached) return;

    menuBtn.dataset.quickHideAttached = 'true';
    menuBtn.title = 'Быстрое скрытие видео';

    const stopEvents = (e) => {
      // Не блокируем события, если они отправлены скриптом
      if (menuBtn.dataset.scriptClick !== 'true') {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
      }
    };

    menuBtn.addEventListener('pointerdown', stopEvents, true);
    menuBtn.addEventListener('mousedown', stopEvents, true);
    menuBtn.addEventListener('mouseup', stopEvents, true);

    menuBtn.addEventListener('click', (e) => handleMenuClick(e, menuBtn, card), true);
  });
}

// Наблюдатель за скроллом и загрузкой
const observer = new MutationObserver(() => processMenuButtons());
observer.observe(document.body, { childList: true, subtree: true });

processMenuButtons();